These ErrorResponses can be sent as a response to any directive from Alexa, and can opportunistically include context properties.
