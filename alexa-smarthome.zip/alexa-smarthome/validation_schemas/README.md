Readme: https://github.com/alexa/alexa-smarthome/wiki/Validation-Schemas
